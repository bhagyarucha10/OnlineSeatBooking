package com.mis.customclasses;

public class Location {
    private String building_location;
    public Location(){}

    public Location(String building_location) {
        this.building_location = building_location;
    }

    public String getBuilding_location() {
        return building_location;
    }

    public void setLocation(String building_location) {
        this.building_location = building_location;
    }
}
