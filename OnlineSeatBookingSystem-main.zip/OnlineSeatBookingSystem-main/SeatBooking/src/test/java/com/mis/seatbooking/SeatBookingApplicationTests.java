package com.mis.seatbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatBookingApplicationTests {

    @Test
    void contextLoads() {
    }

}
